import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4532d47e"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=4532d47e"; const StrictMode = __vite__cjsImport1_react["StrictMode"];
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=4532d47e"; const createRoot = __vite__cjsImport2_reactDom_client["createRoot"];
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=4532d47e";
import "/src/index.css?t=1752248088317";
import App from "/src/App.jsx?t=1752248088317";
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(StrictMode, { children: /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "/Users/appleuser/Documents/Repos/AAU-Fullstack-Assignments/React-Assignments/Library-Manager-System/src/main.jsx",
    lineNumber: 10,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/appleuser/Documents/Repos/AAU-Fullstack-Assignments/React-Assignments/Library-Manager-System/src/main.jsx",
    lineNumber: 9,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/appleuser/Documents/Repos/AAU-Fullstack-Assignments/React-Assignments/Library-Manager-System/src/main.jsx",
    lineNumber: 8,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007QUFUTixTQUFTQSxrQkFBa0I7QUFDM0IsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHFCQUFvQjtBQUM3QixPQUFPO0FBQ1AsT0FBT0MsU0FBUztBQUVoQkYsV0FBV0csU0FBU0MsZUFBZSxNQUFNLENBQUMsRUFBRUM7QUFBQUEsRUFDMUMsdUJBQUMsY0FDQyxpQ0FBQyxpQkFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUNGIiwibmFtZXMiOlsiU3RyaWN0TW9kZSIsImNyZWF0ZVJvb3QiLCJCcm93c2VyUm91dGVyIiwiQXBwIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdHJpY3RNb2RlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBjcmVhdGVSb290IH0gZnJvbSAncmVhY3QtZG9tL2NsaWVudCdcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXJ9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC5qc3gnXG5cbmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxuICA8U3RyaWN0TW9kZT5cbiAgICA8QnJvd3NlclJvdXRlcj5cbiAgICAgIDxBcHAgLz5cbiAgICA8L0Jyb3dzZXJSb3V0ZXI+XG4gIDwvU3RyaWN0TW9kZT4sXG4pXG4iXSwiZmlsZSI6Ii9Vc2Vycy9hcHBsZXVzZXIvRG9jdW1lbnRzL1JlcG9zL0FBVS1GdWxsc3RhY2stQXNzaWdubWVudHMvUmVhY3QtQXNzaWdubWVudHMvTGlicmFyeS1NYW5hZ2VyLVN5c3RlbS9zcmMvbWFpbi5qc3gifQ==